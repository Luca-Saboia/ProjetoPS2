package br.mackenzie.projetops2.repository;

import br.mackenzie.projetops2.model.Evento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EventoRepository extends JpaRepository<Evento, Long> {
    // O JpaRepository já fornece automaticamente: save(), findAll(), findById(), deleteById()
}